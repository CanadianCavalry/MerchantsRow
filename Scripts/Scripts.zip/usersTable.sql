-- Run command: source public_html/scripts/usersTable.sql

Drop Table users;
CREATE TABLE users
(username varchar(20) NOT NULL primary key,
password varchar(20) NOT NULL,
dob DATE NOT NULL,
email varchar(30) NOT NULL,
logged Timestamp default null);

Drop trigger users_sessionEnd;
Create trigger users_sessionEnd
After modify on users
for each row
begin
	if new.logged <> null then
		Create or Alter event sessionExpires
		On schedule
			at current_timestamp + interval 5 minute
		Do
			Update users set logged = null;
	end if;
End;