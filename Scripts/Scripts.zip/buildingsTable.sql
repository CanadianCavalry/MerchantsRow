-- Run command: source public_html/scripts/buildingsTable.sql

Drop Table buildings;
CREATE TABLE buildings
(buildingId integer NOT NULL PRIMARY KEY, 
structureType varchar(20) NOT NULL,
Foreign key (structureType) references structures(structureType),
owner varchar(20),
Foreign key (owner) references users(username),
location varchar(30) NOT NULL);