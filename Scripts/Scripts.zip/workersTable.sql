-- Run command: source public_html/scripts/workersTable.sql

Drop table workers;
CREATE TABLE workers
(workerId integer NOT NULL PRIMARY KEY, 
workerName varchar(20) NOT NULL,
employer varchar(20),
Foreign key (employer) references users(username),
wage INTEGER NOT NULL default 0,
workHours INTEGER NOT NULL default 0);