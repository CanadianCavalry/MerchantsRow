-- Run command: source public_html/scripts/ordersTable.sql

Drop Table orders;
CREATE TABLE orders
(orderId integer NOT NULL PRIMARY KEY, 
orderType varchar(30) NOT NULL, 
item varchar(20) NOT NULL,
Foreign key (item, itemQuality) references goods(goodType, goodQuality),
itemQuality varchar(12) NOT NULL,
itemQuantity INTEGER NOT NULL,
orderValue INTEGER NOT NULL, 
creator varchar(20) NOT NULL,
Foreign key (creator) references users(username),
recipient varchar(20),
Foreign key (recipient) references users(username),
expirationDate DATE NOT NULL);