-- Run command: source public_html/scripts/craftingRecipesTable.sql

Drop Table craftingRecipes;
CREATE TABLE craftingRecipes
(product varchar(20) NOT NULL,
outputQuantity Integer Not Null,
ingredient varchar(20) NOT NULL,
Primary key (product, ingredient),
Foreign key (product) references goods(goodType),
Foreign key (ingredient) references goods(goodType),
inputQuantity INTEGER NOT NULL);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('lumber', 4, 'wood', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('charcoal', 1, 'wood', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('sausage', 1, 'venison', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('flour', 1, 'grain', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('iron', 1, 'iron ore', 4);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('iron', 1, 'coal', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('iron', 1, 'charcoal', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('gold', 1, 'gold ore', 4);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('gold', 1, 'coal', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('gold', 1, 'charcoal', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('fabric', 1, 'wool', 4);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('wine', 1, 'grapes', 4);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('beer', 1, 'grain', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('beer', 1, 'water', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('beer', 1, 'wood', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('cheese', 1, 'milk', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('cart', 1, 'lumber', 10);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('bread', 1, 'flour', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('bread', 1, 'water', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('bread', 1, 'milk', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('tool', 1, 'iron', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('tool', 1, 'coal', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('tool', 1, 'charcoal', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('jewellery', 1, 'gold', 1);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('jewellery', 1, 'coal', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('jewellery', 1, 'charcoal', 2);

Insert into craftingRecipes
(product, outputQuantity, ingredient, inputQuantity)
Values
('clothes', 1, 'fabric', 2);