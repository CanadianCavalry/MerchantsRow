-- Run command: source public_html/scripts/structuresTable.sql

Drop Table structures;
CREATE TABLE structures
(structureType varchar(20) NOT NULL PRIMARY KEY, 
structureSize INTEGER NOT NULL);

Insert into structures
(StructureType, structureSize)
Values
('Warehouse', 5);