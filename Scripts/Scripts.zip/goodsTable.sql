-- Run command: source public_html/scripts/goodsTable.sql

Drop Table goods;
CREATE TABLE goods
(goodType varchar(20) NOT NULL,
goodQuality varchar(12) NOT NULL,
buildingId integer NOT NULL,
Primary key (goodType, goodQuality, buildingId),
Foreign key (buildingId) references buildings(buildingId),
goodQuantity INTEGER NOT NULL default 1,
price integer NOT NULL default 0,
sales integer NOT NULL default 0);