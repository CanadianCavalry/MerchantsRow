-- Run command: source public_html/scripts/skillsTable.sql

Drop Table skills;
CREATE TABLE skills
(skillName varchar(30) NOT NULL, 
workerId integer NOT NULL,
PRIMARY KEY (skillName, workerId),
Foreign key (workerId) references workers(workerId),
skillLevel INTEGER NOT NULL default 1);